
package org.mypackage.hello;

import java.sql.SQLException;

public class NameHandler {
    private String name;
    private String lastName;
    private Database database;
    
    public NameHandler()
    {
        name = null;
        lastName = null;
        try{
        database = new Database();
        database.createDatabase();
        } catch (SQLException ex)
        {
            System.err.printf(ex.getLocalizedMessage(), ex);
        } catch (ClassNotFoundException e)
        {
            System.err.printf(e.getLocalizedMessage(), e);
        }
        
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
}
