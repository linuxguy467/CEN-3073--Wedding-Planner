
package org.mypackage.hello;

import java.sql.*;

public class Database 
{    
    //JDBC driver name and database URL
    static final String driver = "org.h2.Driver";
    static final String databaseURL = "jdbc:h2:~/WeddingPlanner";
    
    //Database Login
    static final String userName = "sa";
    static final String password ="";
    
    private Connection conn;
    private Statement stmt;
    
    public Database() throws SQLException, ClassNotFoundException
    {
        conn = null;
        Statement stmt = null;
    }
    
    public void createDatabase() throws SQLException, ClassNotFoundException
    {
        Class.forName(driver);
        conn = DriverManager.getConnection(databaseURL,userName,password);
    }
    
    public void createStatement(String sql)throws SQLException
    {
        stmt = conn.createStatement();
        stmt.executeUpdate(sql);
    }
    
    public void closeDatabase() throws SQLException
    {
        conn.close();
    }
}
