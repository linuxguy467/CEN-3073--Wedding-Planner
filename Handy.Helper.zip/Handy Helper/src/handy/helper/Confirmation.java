/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package handy.helper;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;


/**
 *
 * @author Anansi
 */
public class Confirmation 
{
    private static boolean answer;
    
    public static boolean displayBox(String title, String message)
    {
        Stage window = new Stage();
        
      
        window.setTitle(title);
        window.initModality(Modality.APPLICATION_MODAL);
        
        Label label = new Label();
        label.setText(message);
        Button yesButton = new Button("Yes");
        yesButton.setOnAction(e -> {
            answer = true;
            window.close();
        });
       
        Button noButton = new Button("No");
        noButton.setOnAction(e -> { 
            answer = false;
            window.close();
        });
        VBox layout = new VBox();
        layout.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(label, yesButton, noButton);
        
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
        
        return answer;
    }
}
