/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package handy.helper;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 *
 * @author Anansi
 */
public class HandyHelper extends Application {
    private Stage stage1;
    private String fxmlName = "fxml_login.fxml";
    
    @Override
    public void start(Stage stage) throws Exception 
    {
        stage1 = stage;
        stage1.setTitle("Handy Helper");
        stage1.setOnCloseRequest(e -> {
            e.consume();
            closeProgram();
        });
        Pane myPane = (Pane) FXMLLoader.load(getClass().getResource(fxmlName));
        Scene myScene = new Scene(myPane);
        stage1.setScene(myScene);
        stage1.show();
    }
    

    public void closeProgram()
    {
        boolean answer = Confirmation.displayBox("Hello", "Are you sure you want to leave\n"
                + " Please dont leave nooo");
        if(answer)
            stage1.close();
    }
    
    public String getFxmlName()
    {
        return fxmlName;
    }
    
    public void setFxmlName(String name)
    {
        fxmlName = name;
    }
    
    public static void main(String[] args) {

        launch(args);
    }
    
}
