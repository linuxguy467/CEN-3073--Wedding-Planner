/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package handy.helper;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author Anansi
 */
public class Contacts 
{
    private final SimpleStringProperty firstName = new SimpleStringProperty("");
    private final SimpleStringProperty lastName = new SimpleStringProperty("");
    private final SimpleStringProperty phoneNumber = new SimpleStringProperty("");
    private final SimpleStringProperty email = new SimpleStringProperty("");
    
    public Contacts()
    {
        this("","","","");
    }
    public Contacts(String firstName, String lastName, String  phoneNumber, String email)
    {
        setFirstName(firstName);
        setLastName(lastName);
        setPhoneNumber(phoneNumber);
        setEmail(email);
    }

    //These are the get methods for the name and number
    public String getFirstName()
    {
        return firstName.get();
    }
    public String getLastName()
    {
        return lastName.get();
    }
    public String getPhoneNumber()
    {
        return phoneNumber.get();
    }
    public String getEmail()
    {
        return email.get();
    }
    //These are the set methods for the name and number
    public void setFirstName(String fName) 
    {
        firstName.set(fName);
    }

    public void setLastName(String lName) 
    {
        lastName.set(lName);
    }

    public void setPhoneNumber(String pNumber) 
    {
        phoneNumber.set(pNumber);
    }
    public void setEmail(String mail)
    {
        email.set(mail);
    }
}
